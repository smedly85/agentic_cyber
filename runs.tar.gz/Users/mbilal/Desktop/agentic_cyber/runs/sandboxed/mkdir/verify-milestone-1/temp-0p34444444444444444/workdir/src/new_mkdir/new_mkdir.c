#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>

int main(int argc, char **argv) {
    int start_operand = 1;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--") == 0) {
            start_operand = i + 1;
            break;
        } else if (argv[i][0] == '-') {
            if (strcmp(argv[i], "-") != 0) {
                fprintf(stderr, "mkdir: unrecognized option '%s'\n", argv[i]);
                fprintf(stderr, "Try 'mkdir --help' for more information.\n");
                return 1;
            }
        }
    }

    if (start_operand >= argc) {
            fprintf(stderr, "mkdir: missing operand\n");
            fprintf(stderr, "Try 'mkdir --help' for more information.\n");
            return 1;
    }

    int failed = 0;
    for (int i = start_operand; i < argc; i++) {
        if (mkdir(argv[i], 0777) != 0) {
                fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", argv[i], strerror(errno));
            failed = 1;
        }
    }

    return failed;
}
