#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <libgen.h>

int main(int argc, char **argv) {
    int saw_dashdash = 0;
    int num_operands = 0;

    for (int i = 1; i < argc; i++) {
        if (!saw_dashdash && strcmp(argv[i], "--") == 0) {
            saw_dashdash = 1;
            continue;
        }
        if (!saw_dashdash && argv[i][0] == '-' && argv[i][1] != '\0') {
            fprintf(stderr, "mkdir: unrecognized option '%s'\nTry 'mkdir --help' for more information.\n", argv[i]);
            return 1;
        }
        num_operands++;
    }

    if (num_operands == 0) {
        fprintf(stderr, "mkdir: missing operand\nTry 'mkdir --help' for more information.\n");
        return 1;
    }

    int failure_count = 0;
    saw_dashdash = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--") == 0) {
            saw_dashdash = 1;
            continue;
        }

        char *operand = argv[i];
        char *path = strdup(operand);
        if (!path) {
            fprintf(stderr, "new_mkdir: out of memory\n");
            return 1;
        }

        char *dpath = strdup(path);
        char *bpath = strdup(path);
        if (!dpath || !bpath) {
            free(path);
            fprintf(stderr, "new_mkdir: out of memory\n");
            return 1;
        }

        char *parent = dirname(dpath);
        char *base = basename(bpath);

        struct stat st;
        if (stat(parent, &st) == -1) {
            if (errno == ENOENT) {
                fprintf(stderr, "mkdir: cannot create directory '%s': No such file or directory\n", operand);
            } else {
                fprintf(stderr, "new_mkdir: cannot create directory '%s': %s\n", operand, strerror(errno));
            }
            failure_count++;
            free(path);
            free(dpath);
            free(bpath);
            continue;
        }

        if (!S_ISDIR(st.st_mode)) {
            fprintf(stderr, "mkdir: cannot create directory '%s': Not a directory\n", operand);
            failure_count++;
            free(path);
            free(dpath);
            free(bpath);
            continue;
        }

        char final_path[1024];
        snprintf(final_path, sizeof(final_path), "%s/%s", parent, base);

        if (stat(final_path, &st) != -1) {
            fprintf(stderr, "mkdir: cannot create directory '%s': File exists\n", operand);
            failure_count++;
            free(path);
            free(dpath);
            free(bpath);
            continue;
        } else if (errno != ENOENT) {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': %s\n", operand, strerror(errno));
            failure_count++;
            free(path);
            free(dpath);
            free(bpath);
            continue;
        }

        if (mkdir(final_path, 0777) == -1) {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': %s\n", operand, strerror(errno));
            failure_count++;
        }

        free(path);
        free(dpath);
        free(bpath);
    }

    return (failure_count > 0) ? 1 : 0;
}
