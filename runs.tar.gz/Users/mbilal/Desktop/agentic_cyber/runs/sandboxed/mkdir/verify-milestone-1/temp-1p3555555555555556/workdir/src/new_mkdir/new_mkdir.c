#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <limits.h>

int main(int argc, char *argv[]) {
    int i = 1;
    int operands_start = 1;

    while (i < argc) {
        if (strcmp(argv[i], "--") == 0) {
            i++;
            break;
        }
        if (argv[i][0] == '-' && strcmp(argv[i], "-") != 0) {
            fprintf(stderr, "mkdir: unrecognized option '%s'\nTry 'mkdir --help' for more information.\n", argv[i]);
            return 1;
        }
        if (argv[i][0] != '-' || strcmp(argv[i], "-") == 0) {
            break;
        }
        i++;
    }
    operands_start = i;

    if (operands_start >= argc) {
        fprintf(stderr, "mkdir: missing operand\nTry 'mkdir --help' for more information.\n");
        return 1;
    }

    int failed = 0;
    for (int j = operands_start; j < argc; j++) {
        char *path = argv[j];
        size_t len = strlen(path);
        while (len > 0 && path[len-1] == '/') {
            len--;
        }
        char stripped_path[PATH_MAX];
        if (len == 0) {
            stripped_path[0] = '/';
            stripped_path[1] = '\0';
        } else {
            strncpy(stripped_path, path, len);
            stripped_path[len] = '\0';
        }
        path = stripped_path;

        char parent[PATH_MAX];
        char leaf[PATH_MAX];
        char *last_slash = strrchr(path, '/');
        if (last_slash != NULL) {
            size_t parent_len = last_slash - path;
            if (parent_len == 0) {
                strcpy(parent, "/");
            } else {
                strncpy(parent, path, parent_len);
                parent[parent_len] = '\0';
            }
            strcpy(leaf, last_slash + 1);
        } else {
            strcpy(parent, ".");
            strcpy(leaf, path);
        }

        if (leaf[0] == '\0') {
            fprintf(stderr, "mkdir: cannot create directory '%s': Invalid path\n", argv[j]);
            failed = 1;
            continue;
        }

        struct stat st;
        if (stat(parent, &st) != 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", argv[j], strerror(errno));
            failed = 1;
            continue;
        }
        if (!S_ISDIR(st.st_mode)) {
            fprintf(stderr, "mkdir: cannot create directory '%s': Not a directory\n", argv[j]);
            failed = 1;
            continue;
        }

        char full_path[PATH_MAX];
        snprintf(full_path, sizeof(full_path), "%s/%s", parent, leaf);
        if (stat(full_path, &st) == 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': File exists\n", argv[j]);
            failed = 1;
            continue;
        }

        if (mkdir(full_path, 0777) != 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", argv[j], strerror(errno));
            failed = 1;
            continue;
        }
    }

    return failed ? 1 : 0;
}
