#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <libgen.h>

int main(int argc, char *argv[]) {
        int operands_start = 1;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--") == 0) {
            operands_start = i + 1;

            break;
        }
        if (argv[i][0] == '-' && argv[i][1] != '\0' && !(argv[i][1] == '-' && argv[i][2] == '\0')) {
            fprintf(stderr, "mkdir: unrecognized option '%s'\nTry 'mkdir --help' for more information.\n", argv[i]);
            return 1;
        }
    }

        if (operands_start >= argc) {
            fprintf(stderr, "mkdir: missing operand\nTry 'mkdir --help' for more information.\n");
            return 1;
        }

    int failed = 0;
    for (int i = operands_start; i < argc; i++) {
        char *operand = argv[i];
        char *path_copy = strdup(operand);
        if (!path_copy) {
            fprintf(stderr, "mkdir: memory allocation error\n");
            failed = 1;
            continue;
        }

        char *parent = dirname(path_copy);

        struct stat st;
        if (stat(parent, &st) != 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", operand, strerror(errno));
            free(path_copy);
            failed = 1;
            continue;
        }
        if (!S_ISDIR(st.st_mode)) {
            fprintf(stderr, "mkdir: cannot create directory '%s': Not a directory\n", operand);
            free(path_copy);
            failed = 1;
            continue;
        }

        free(path_copy);

        if (stat(operand, &st) == 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': File exists\n", operand);
            failed = 1;
            continue;
        }

        if (mkdir(operand, 0777) != 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", operand, strerror(errno));
            failed = 1;
        }
    }

    return failed ? 1 : 0;
}
