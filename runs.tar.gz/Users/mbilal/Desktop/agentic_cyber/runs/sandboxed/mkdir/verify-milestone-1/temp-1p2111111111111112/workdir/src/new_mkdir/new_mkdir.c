#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <errno.h>

int main(int argc, char *argv[]) {
        if (argc <= 1) {
            fprintf(stderr, "mkdir: missing operand\nTry 'mkdir --help' for more information.\n");
            return 1;
        }

        int i = 1;
        int after_double_dash = 0;
        char **operands = NULL;
        int num_operands = 0;

        for (; i < argc; i++) {
            if (!after_double_dash && strcmp(argv[i], "--") == 0) {
                after_double_dash = 1;
                continue;
            }

            if (!after_double_dash && argv[i][0] == '-' && strcmp(argv[i], "-") != 0) {
                fprintf(stderr, "mkdir: unrecognized option '%s'\nTry 'mkdir --help' for more information.\n", argv[i]);
                return 1;
            }

            num_operands++;
            operands = realloc(operands, num_operands * sizeof(char *));
            if (!operands) {
                fprintf(stderr, "mkdir: memory allocation failed\n");
                return 1;
            }
            operands[num_operands-1] = argv[i];
        }

        if (num_operands == 0) {
            fprintf(stderr, "mkdir: missing operand\nTry 'mkdir --help' for more information.\n");
            return 1;
        }

        int all_success = 1;

        for (i = 0; i < num_operands; i++) {
            char *path = operands[i];
            char *dup = strdup(path);
            if (!dup) {
                fprintf(stderr, "mkdir: memory allocation failed\n");
                all_success = 0;
                continue;
            }

            // Trim trailing slashes
            size_t len = strlen(dup);
            while (len > 0 && dup[len - 1] == '/') {
                dup[--len] = '\0';
            }

            char *leaf = strrchr(dup, '/');
            char *parent_path;

            if (leaf) {
                *leaf = '\0';
                leaf++;
                parent_path = dup;
                if (parent_path[0] == '\0') parent_path = "/";
            } else {
                leaf = dup;
                parent_path = ".";
            }

            struct stat st;
            if (stat(parent_path, &st) != 0) {
                fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
                free(dup);
                all_success = 0;
                continue;
            }

            if (!S_ISDIR(st.st_mode)) {
                fprintf(stderr, "mkdir: cannot create directory '%s': Not a directory\n", path);
                free(dup);
                all_success = 0;
                continue;
            }

            if (stat(path, &st) == 0) {
                fprintf(stderr, "mkdir: cannot create directory '%s': File exists\n", path);
                free(dup);
                all_success = 0;
                continue;
            }

            if (mkdir(path, 0777) != 0) {
                fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
                free(dup);
                all_success = 0;
                continue;
            }

            free(dup);
        }

        free(operands);
        return all_success ? 0 : 1;
}

