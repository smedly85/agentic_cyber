#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <limits.h>

int main(int argc, char *argv[]) {
    int i = 1;
    // Process options
    while (i < argc && argv[i][0] == '-' && argv[i][1] != '\0') {
        if (strcmp(argv[i], "--") == 0) {
            i++;
            break;
        }


        if (strcmp(argv[i], "-") == 0) {
            break;
        }


        fprintf(stderr, "mkdir: unrecognized option '%s'\nTry 'mkdir --help' for more information.\n", argv[i]);
        exit(1);
    }


    if (i >= argc) {
        fprintf(stderr, "mkdir: missing operand\nTry 'mkdir --help' for more information.\n");
        exit(1);
    }



    int failures = 0;
    for (; i < argc; i++) {
        const char *operand = argv[i];
        char clean[PATH_MAX];
        strncpy(clean, operand, PATH_MAX);
        clean[PATH_MAX-1] = '\0';

        size_t len = strlen(clean);
        while (len > 0 && clean[len-1] == '/') {
            clean[len-1] = '\0';
            len--;
        }



        char parent[PATH_MAX];
        char base[PATH_MAX];
        if (len == 0) {
            strcpy(parent, "/");
            base[0] = '\0';
        }

 else {
            char *last_slash = strrchr(clean, '/');
            if (last_slash && last_slash == clean) {
                strcpy(parent, "/");
                strcpy(base, last_slash + 1);
            }

 else if (last_slash) {
                *last_slash = '\0';
                strcpy(parent, clean);
                strcpy(base, last_slash + 1);
            }

 else {
                strcpy(parent, ".");
                strcpy(base, clean);
            }


        }



        if (base[0] == '\0') {
            fprintf(stderr, "mkdir: cannot create directory '%s': Invalid argument\n", operand);
            failures++;
            continue;
        }



        struct stat st;
        if (stat(parent, &st) != 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", operand, strerror(errno));
            failures++;
            continue;
        }


        if (!S_ISDIR(st.st_mode)) {
            fprintf(stderr, "mkdir: cannot create directory '%s': Not a directory\n", operand);
            failures++;
            continue;
        }



        char fullpath[PATH_MAX];
        snprintf(fullpath, sizeof(fullpath), "%s/%s", parent, base);
        if (stat(fullpath, &st) == 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': File exists\n", operand);
            failures++;
            continue;
        }



        if (mkdir(fullpath, 0777) != 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", operand, strerror(errno));
            failures++;
        }


    }


    exit(failures ? 1 : 0);
}

