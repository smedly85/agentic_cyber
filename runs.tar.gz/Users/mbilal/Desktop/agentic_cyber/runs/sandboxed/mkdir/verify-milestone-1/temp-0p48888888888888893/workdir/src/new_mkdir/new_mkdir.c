#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char *argv[]) {
    char **operands = NULL;
    int operand_count = 0;
    int found_double_dash = 0;

    for (int i = 1; i < argc; i++) {
        if (found_double_dash) {
            operand_count++;
            operands = realloc(operands, operand_count * sizeof(char*));
            if (operand_count > 0 && !operands) {
                fprintf(stderr, "mkdir: out of memory\n");
                exit(1);
            }

            operands[operand_count - 1] = argv[i];
        }
 else {
            if (strcmp(argv[i], "--") == 0) {
                found_double_dash = 1;
                continue;
            }
 else if (argv[i][0] == '-') {
                if (strcmp(argv[i], "-") == 0) {
                    operand_count++;
                    operands = realloc(operands, operand_count * sizeof(char*));
                    if (operand_count > 0 && !operands) {
                        fprintf(stderr, "mkdir: out of memory\n");
                        exit(1);
                    }

                    operands[operand_count - 1] = argv[i];
                }
 else {
                    fprintf(stderr, "mkdir: invalid option '%s'\n", argv[i]);
                    exit(1);
                }

            }
 else {
                operand_count++;
                operands = realloc(operands, operand_count * sizeof(char*));
                if (operand_count > 0 && !operands) {
                    fprintf(stderr, "mkdir: out of memory\n");
                    exit(1);
                }

                operands[operand_count - 1] = argv[i];
            }

        }

    }


    if (operand_count == 0) {
        fprintf(stderr, "mkdir: missing operand\n");
        exit(1);
    }


    int any_failure = 0;
    for (int i = 0; i < operand_count; i++) {
        char *dir = operands[i];
        char *slash = strrchr(dir, '/');
        char *parent_path = ".";
        char *component;
        int allocated_parent = 0;

        if (slash) {
            size_t parent_len = slash - dir;
            if (parent_len == 0) {
                if (dir[0] == '/') {
                    parent_path = "/";
                }
 else {
                    parent_path = ".";
                }

                allocated_parent = 0;
            }
 else {
                parent_path = malloc(parent_len + 1);
                if (!parent_path) {
                    fprintf(stderr, "mkdir: out of memory\n");
                    exit(1);
                }

                strncpy(parent_path, dir, parent_len);
                parent_path[parent_len] = '\0';
                allocated_parent = 1;
            }

            component = slash + 1;
        }
 else {
            parent_path = ".";
            component = dir;
            allocated_parent = 0;
        }


        struct stat sb;
        if (stat(parent_path, &sb) != 0) {
            if (errno == ENOENT) {
                fprintf(stderr, "mkdir: cannot create directory '%s': No such file or directory\n", dir);
            }
 else {
                fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", dir, strerror(errno));
            }

            any_failure = 1;
            if (allocated_parent) free(parent_path);
            continue;
        }


        if (!S_ISDIR(sb.st_mode)) {
            fprintf(stderr, "mkdir: cannot create directory '%s': Not a directory\n", dir);
            any_failure = 1;
            if (allocated_parent) free(parent_path);
            continue;
        }


        size_t full_path_len = strlen(parent_path) + strlen(component) + 2;
        char *full_path = malloc(full_path_len);
        if (!full_path) {
            fprintf(stderr, "mkdir: out of memory\n");
            if (allocated_parent) free(parent_path);
            exit(1);
        }


        if (strcmp(parent_path, "/") == 0) {
            snprintf(full_path, full_path_len, "/%s", component);
        }
 else {
            snprintf(full_path, full_path_len, "%s/%s", parent_path, component);
        }


        struct stat sb_component;
        if (stat(full_path, &sb_component) == 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': File exists\n", dir);
            any_failure = 1;
            free(full_path);
            if (allocated_parent) free(parent_path);
            continue;
        }


        if (mkdir(full_path, 0777) != 0) {
            if (errno == EACCES) {
                fprintf(stderr, "mkdir: cannot create directory '%s': Permission denied\n", dir);
            }
 else {
                fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", dir, strerror(errno));
            }

            any_failure = 1;
        }


        free(full_path);
        if (allocated_parent) free(parent_path);
    }


    free(operands);
    exit(any_failure ? 1 : 0);
}
