#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <libgen.h>

int main(int argc, char *argv[]) {
    int first_operand = 1;
    while (first_operand < argc && strcmp(argv[first_operand], "--") != 0) {
        if (argv[first_operand][0] == '-' && argv[first_operand][1] != '\0') {
            if (strcmp(argv[first_operand], "-") != 0 && strcmp(argv[first_operand], "--") != 0) {
                fprintf(stderr, "new_mkdir: invalid option -- '%s'\n", argv[first_operand] + 1);
                return 1;
            }
        }
        first_operand++;
    }
    if (first_operand < argc && strcmp(argv[first_operand], "--") == 0) {
        first_operand++;
    }
    if (first_operand >= argc) {
        fprintf(stderr, "new_mkdir: missing operand\n");
        return 1;
    }
    int all_success = 1;
    for (int i = first_operand; i < argc; i++) {
        char *path = strdup(argv[i]);
        if (!path) {
            perror("new_mkdir");
            all_success = 0;
            continue;
        }
        char *dir_copy = strdup(path);
        char *base_copy = strdup(path);
        if (!dir_copy || !base_copy) {
            perror("new_mkdir");
            free(path);
            free(dir_copy);
            free(base_copy);
            all_success = 0;
            continue;
        }
        char *dname = dirname(dir_copy);
        // Removed unused variable

        struct stat st;
        if (stat(dname, &st) != 0) {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': %s\n", argv[i], strerror(errno));
            all_success = 0;
        } else if (!S_ISDIR(st.st_mode)) {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': Not a directory\n", argv[i]);
            all_success = 0;
        } else {
            if (stat(argv[i], &st) == 0) {
                fprintf(stderr, "new_mkdir: cannot create directory '%s': File exists\n", argv[i]);
                all_success = 0;
            } else {
                if (mkdir(argv[i], 0777) != 0) {
                    fprintf(stderr, "new_mkdir: cannot create directory '%s': %s\n", argv[i], strerror(errno));
                    all_success = 0;
}

            }
        }
        free(path);
        free(dir_copy);
        free(base_copy);
    }
    return all_success ? 0 : 1;
}
