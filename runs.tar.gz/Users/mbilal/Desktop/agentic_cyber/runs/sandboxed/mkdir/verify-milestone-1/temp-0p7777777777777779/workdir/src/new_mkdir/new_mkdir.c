#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <libgen.h>
#include <sys/stat.h>
#include <sys/types.h>

int process_operand(char *path) {
    char *d = strdup(path);
    if (!d) {
        perror("strdup");
        exit(1);
    }
    char *dir = dirname(d);

    char *b = strdup(path);
    if (!b) {
        perror("strdup");
        exit(1);
    }

    struct stat st;

    if (stat(dir, &st) != 0) {
        if (errno == ENOENT) {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': No such file or directory\n", path);
        } else {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
        }
        free(d);
        free(b);
        return 0;
    }

    if (!S_ISDIR(st.st_mode)) {
        fprintf(stderr, "new_mkdir: cannot create directory '%s': Not a directory\n", path);
        free(d);
        free(b);
        return 0;
    }

    if (stat(path, &st) == 0) {
        fprintf(stderr, "new_mkdir: cannot create directory '%s': File exists\n", path);
        free(d);
        free(b);
        return 0;
    }

    if (errno != ENOENT) {
        fprintf(stderr, "new_mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
        free(d);
        free(b);
        return 0;
    }

    if (mkdir(path, 0777) != 0) {
        fprintf(stderr, "new_mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
        free(d);
        free(b);
        return 0;
    }

    free(d);
    free(b);
    return 1;
}

int main(int argc, char **argv) {
    int found_double_dash = 0;
    char **operands = NULL;
    int op_count = 0;

    for (int i = 1; i < argc; i++) {
        if (found_double_dash) {
            char **tmp = realloc(operands, (op_count + 1) * sizeof(char *));
            if (!tmp) {
                perror("realloc");
                exit(1);
            }
            operands = tmp;
            operands[op_count++] = argv[i];
            continue;
        }
        if (strcmp(argv[i], "--") == 0) {
            found_double_dash = 1;
            continue;
        }
        if (argv[i][0] == '-') {
            if (strcmp(argv[i], "-") != 0) {
                fprintf(stderr, "new_mkdir: invalid option -- '%s'\n", argv[i] + 1);
                exit(1);
            }
        }
        char **tmp = realloc(operands, (op_count + 1) * sizeof(char *));
        if (!tmp) {
            perror("realloc");
            exit(1);
        }
        operands = tmp;
        operands[op_count++] = argv[i];
    }

    if (op_count == 0) {
        fprintf(stderr, "new_mkdir: missing operand\n");
        exit(1);
    }

    int success_count = 0;
    for (int i = 0; i < op_count; i++) {
        if (process_operand(operands[i])) {
            success_count++;
        }
    }

    free(operands);

    if (success_count != op_count) {
        return 1;
    }

    return 0;
}
