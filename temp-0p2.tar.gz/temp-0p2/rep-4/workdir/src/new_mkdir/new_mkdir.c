#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    int i = 1;
    int first_operand_index = 1;

    while (i < argc) {
        if (strcmp(argv[i], "--") == 0) {
            first_operand_index = i + 1;
            break;
        }
        if (argv[i][0] == '-' && strcmp(argv[i], "-") != 0) {
            fprintf(stderr, "mkdir: unrecognized option '%s'\n", argv[i]);
            fprintf(stderr, "Try 'mkdir --help' for more information.\n");
            return 1;
        }
        i++;
    }

    if (i == argc) {
        first_operand_index = 1;
    }

    if (first_operand_index >= argc) {
        fprintf(stderr, "mkdir: missing operand\n");
        fprintf(stderr, "Try 'mkdir --help' for more information.\n");
        return 1;
    }

    int error_occurred = 0;

    for (int j = first_operand_index; j < argc; j++) {
        char *path = argv[j];
        char *path_dup = strdup(path);
        if (!path_dup) {
            fprintf(stderr, "mkdir: memory allocation failed\n");
            exit(1);
        }

        // Trim trailing slashes
        size_t len = strlen(path_dup);
        while (len > 0 && path_dup[len-1] == '/') {
            len--;
        }
        path_dup[len] = '\0';

        if (len == 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': Invalid argument\n", path);
            free(path_dup);
            error_occurred = 1;
            continue;
        }

        char *parent_path;
        char *leaf_name = strrchr(path_dup, '/');
        if (leaf_name) {
            *leaf_name = '\0';
            leaf_name++;
            parent_path = path_dup;
        } else {
            leaf_name = path_dup;
            parent_path = ".";
        }

        struct stat st;

        if (stat(parent_path, &st) != 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
            free(path_dup);
            error_occurred = 1;
            continue;
        }

        if (!S_ISDIR(st.st_mode)) {
            errno = ENOTDIR;
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
            free(path_dup);
            error_occurred = 1;
            continue;
        }

        if (stat(path, &st) == 0) {
            errno = EEXIST;
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
            free(path_dup);
            error_occurred = 1;
            continue;
        } else if (errno != ENOENT) {
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
            free(path_dup);
            error_occurred = 1;
            continue;
        }

        if (mkdir(path, 0777) != 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
            free(path_dup);
            error_occurred = 1;
            continue;
        }

        free(path_dup);
    }

    return error_occurred ? 1 : 0;
}
