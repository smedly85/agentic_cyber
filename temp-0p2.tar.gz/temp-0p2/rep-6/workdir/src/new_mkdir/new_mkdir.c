#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <libgen.h>

int main(int argc, char *argv[]) {
    int operands_start = 1;
    int i;

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--") == 0) {
            operands_start = i + 1;
            break;
        }
    }

    for (i = 1; i < operands_start - 1; i++) {
        if (argv[i][0] == '-' && strcmp(argv[i], "-") != 0) {
            fprintf(stderr, "new_mkdir: invalid option '%s'\n", argv[i]);
            return 1;
        }
    }

    if (operands_start == 1) {
        for (i = 1; i < argc; i++) {
            if (argv[i][0] == '-' && strcmp(argv[i], "-") != 0) {
                fprintf(stderr, "new_mkdir: invalid option '%s'\n", argv[i]);
                return 1;
            }
        }
    }

    int num_operands = argc - operands_start;
    if (num_operands <= 0) {
        fprintf(stderr, "new_mkdir: missing operand\n");
        return 1;
    }

    int failed = 0;
    for (i = operands_start; i < argc; i++) {
        char *operand = argv[i];
        char *path = strdup(operand);
        if (!path) {
            fprintf(stderr, "new_mkdir: memory allocation error\n");
            failed = 1;
            continue;
        }
        char *parent = dirname(path);

        char *bpath = strdup(operand);
        if (!bpath) {
            free(path);
            fprintf(stderr, "new_mkdir: memory allocation error\n");
            failed = 1;
            continue;
        }
        char *final = basename(bpath);

        struct stat st;
        if (stat(parent, &st) == -1) {
            if (errno == ENOENT) {
                fprintf(stderr, "new_mkdir: cannot create directory '%s': No such file or directory\n", operand);
            } else {
                fprintf(stderr, "new_mkdir: cannot create directory '%s': %s\n", operand, strerror(errno));
            }
            free(path);
            free(bpath);
            failed = 1;
            continue;
        }

        if (!S_ISDIR(st.st_mode)) {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': Not a directory\n", operand);
            free(path);
            free(bpath);
            failed = 1;
            continue;
        }

        size_t len = strlen(parent) + strlen(final) + 2;
        char *fullpath = malloc(len);
        if (!fullpath) {
            fprintf(stderr, "new_mkdir: memory allocation error\n");
            free(path);
            free(bpath);
            failed = 1;
            continue;
        }
        snprintf(fullpath, len, "%s/%s", parent, final);

        if (lstat(fullpath, &st) == 0) {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': File exists\n", operand);
            free(fullpath);
            free(path);
            free(bpath);
            failed = 1;
            continue;
        } else if (errno != ENOENT) {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': %s\n", operand, strerror(errno));
            free(fullpath);
            free(path);
            free(bpath);
            failed = 1;
            continue;
        }

        if (mkdir(fullpath, 0777) == -1) {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': %s\n", operand, strerror(errno));
            free(fullpath);
            free(path);
            free(bpath);
            failed = 1;
            continue;
        }

        free(fullpath);
        free(path);
        free(bpath);
    }

    return failed ? 1 : 0;
}
