#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libgen.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    int optind = 1;
    while (optind < argc && argv[optind][0] == '-') {
        if (argv[optind][1] == '\0') break;
        else if (argv[optind][1] == '-' && argv[optind][2] == '\0') {
            optind++;
            break;
        }         else {
            fprintf(stderr, "mkdir: unrecognized option '%s'\nTry 'mkdir --help' for more information.\n", argv[optind]);
            return 1;
        }
    }

    if (optind >= argc) {
        fprintf(stderr, "mkdir: missing operand\nTry 'mkdir --help' for more information.\n");
        return 1;
    }

    int failed = 0;
    for (int i = optind; i < argc; i++) {
        char *path = argv[i];
        char *path_copy = strdup(path);
        if (!path_copy) {
            fprintf(stderr, "out of memory\n");
            return 1;
        }
        char *dir = dirname(path_copy);
        struct stat st;
        int error = 0;

        if (stat(dir, &st) != 0) error = errno;
        else if (!S_ISDIR(st.st_mode)) error = ENOTDIR;
        if (!error && stat(path, &st) == 0) error = EEXIST;
        if (!error && mkdir(path, 0777) != 0) error = errno;

        if (error) {
            errno = error;
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
            failed = 1;
        }
        free(path_copy);
    }
    return failed ? 1 : 0;
}
