#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <limits.h>

int create_directory(const char *path) {
    char *path_copy = strdup(path);
    if (!path_copy) {
        fprintf(stderr, "mkdir: memory allocation failed\n");
        exit(1);
    }

    // Remove trailing slashes
    size_t path_len = strlen(path_copy);
    if (path_len > 1) {
        while (path_len > 0 && path_copy[path_len-1] == '/') {
            path_copy[path_len-1] = '\0';
            path_len--;
        }
    }

    char *final = strrchr(path_copy, '/');
    char parent[PATH_MAX];
    if (final) {
        *final = '\0';
        final++;
        if (path_copy[0] == '\0') {
            strcpy(parent, "/");
        } else {
            strncpy(parent, path_copy, sizeof(parent) - 1);
            parent[sizeof(parent) - 1] = '\0';
        }
    } else {
        strcpy(parent, ".");
        final = path_copy;
    }

    struct stat st;
    if (stat(parent, &st) != 0) {
        fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
        free(path_copy);
        return 0;
    }
    if (!S_ISDIR(st.st_mode)) {
        fprintf(stderr, "mkdir: cannot create directory '%s': Not a directory\n", path);
        free(path_copy);
        return 0;
    }

    char full_path[PATH_MAX];
    if (strcmp(parent, "/") == 0) {
        snprintf(full_path, sizeof(full_path), "/%s", final);
    } else {
        snprintf(full_path, sizeof(full_path), "%s/%s", parent, final);
    }

    if (stat(full_path, &st) == 0) {
        fprintf(stderr, "mkdir: cannot create directory '%s': File exists\n", path);
        free(path_copy);
        return 0;
    } else if (errno != ENOENT) {
        fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
        free(path_copy);
        return 0;
    }

    if (mkdir(full_path, 0777) != 0) {
        fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
        free(path_copy);
        return 0;
    }

    free(path_copy);
    return 1;
}

int main(int argc, char *argv[]) {
    int operand_start = 1;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--") == 0) {
            operand_start = i + 1;
            break;
    } else if (argv[i][0] == '-' && strcmp(argv[i], "-") != 0) {
        fprintf(stderr, "mkdir: unrecognized option '%s'\nTry 'mkdir --help' for more information.\n", argv[i]);
        return 1;
    }
    }

    if (operand_start >= argc) {
        fprintf(stderr, "mkdir: missing operand\nTry 'mkdir --help' for more information.\n");
        return 1;
    }

    int all_success = 1;
    for (int i = operand_start; i < argc; i++) {
        if (!create_directory(argv[i])) {
            all_success = 0;
        }
    }

    return all_success ? 0 : 1;
}
