#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <libgen.h>
#include <errno.h>

int process_operand(const char *path) {
    char *path_copy = strdup(path);
    if (!path_copy) {
        fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, "memory allocation error");
        return 0;
    }
    char *dir = dirname(path_copy);
    char *base = strdup(path);
    if (!base) {
        fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, "memory allocation error");
        free(path_copy);
        return 0;
    }
    char *base_cpy = basename(base);

    struct stat st;

    if (stat(dir, &st) != 0) {
        char *reason = strerror(errno);
        fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, reason);
        free(path_copy);
        free(base);
        return 0;
    }
    if (!S_ISDIR(st.st_mode)) {
        fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, "Not a directory");
        free(path_copy);
        free(base);
        return 0;
    }

    char *full_path = malloc(strlen(dir) + strlen(base_cpy) + 2);
    if (!full_path) {
        fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, "memory allocation error");
        free(path_copy);
        free(base);
        return 0;
    }
    strcpy(full_path, dir);
    strcat(full_path, "/");
    strcat(full_path, base_cpy);

    if (stat(full_path, &st) == 0) {
        fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, "File exists");
        free(full_path);
        free(path_copy);
        free(base);
        return 0;
    }
    if (errno != ENOENT) {
        char *reason = strerror(errno);
        fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, reason);
        free(full_path);
        free(path_copy);
        free(base);
        return 0;
    }

    if (mkdir(full_path, 0777) != 0) {
        char *reason = strerror(errno);
        fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, reason);
        free(full_path);
        free(path_copy);
        free(base);
        return 0;
    }

    free(full_path);
    free(path_copy);
    free(base);
    return 1;
}

int main(int argc, char *argv[]) {
    int operand_start = 1;
    int i;
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--") == 0) {
            operand_start = i + 1;
            break;
        }
        if (argv[i][0] == '-' && (strcmp(argv[i], "-") != 0 && strcmp(argv[i], "--") != 0)) {
            fprintf(stderr, "mkdir: unrecognized option '%s'\nTry 'mkdir --help' for more information.\n", argv[i]);
            return 1;
        }
    }

    if (operand_start >= argc) {
        fprintf(stderr, "mkdir: missing operand\nTry 'mkdir --help' for more information.\n");
        return 1;
    }

    int success = 1;
    for (int j = operand_start; j < argc; j++) {
        if (process_operand(argv[j]) != 1) {
            success = 0;
        }
    }

    return success ? 0 : 1;
}
