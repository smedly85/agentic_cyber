#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char **argv) {
    int optind = 1;
    while (optind < argc) {
        if (strcmp(argv[optind], "--") == 0) {
            optind++;
            break;
        }
        if (argv[optind][0] == '-' && strcmp(argv[optind], "-") != 0) {
            fprintf(stderr, "mkdir: unrecognized option '%s'\nTry 'mkdir --help' for more information.\n", argv[optind]);
            return 1;
        }
        break;
    }
    if (optind >= argc) {
        fprintf(stderr, "mkdir: missing operand\nTry 'mkdir --help' for more information.\n");
        return 1;
    }

    int failures = 0;
    for (int i = optind; i < argc; i++) {
        char *path = argv[i];
        char trimmed[PATH_MAX];
        strncpy(trimmed, path, PATH_MAX - 1);
        trimmed[PATH_MAX - 1] = '\0';
        size_t len = strlen(trimmed);
        while (len > 1 && trimmed[len - 1] == '/') {
            trimmed[len - 1] = '\0';
            len--;
        }

        char *last_slash = strrchr(trimmed, '/');
        char parent[PATH_MAX];
        if (last_slash) {
            if (last_slash == trimmed) {
                strcpy(parent, "/");
            } else {
                size_t parent_len = last_slash - trimmed;
                strncpy(parent, trimmed, parent_len);
                parent[parent_len] = '\0';
            }
        } else {
            strcpy(parent, ".");
        }

        struct stat sb;
        if (stat(parent, &sb) != 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
            failures++;
            continue;
        }
        if (!S_ISDIR(sb.st_mode)) {
            fprintf(stderr, "mkdir: cannot create directory '%s': Not a directory\n", path);
            failures++;
            continue;
        }

        if (stat(trimmed, &sb) == 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': File exists\n", path);
            failures++;
            continue;
        } else if (errno != ENOENT) {
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
            failures++;
            continue;
        }

        if (mkdir(trimmed, 0777) != 0) {
            switch (errno) {
                case EEXIST:
                    fprintf(stderr, "mkdir: cannot create directory '%s': File exists\n", path);
                    break;
                case EACCES:
                case EROFS:
                    fprintf(stderr, "mkdir: cannot create directory '%s': Permission denied\n", path);
                    break;
                default:
                    fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
                    break;
            }
            failures++;
        }
    }
    return failures ? 1 : 0;
}
