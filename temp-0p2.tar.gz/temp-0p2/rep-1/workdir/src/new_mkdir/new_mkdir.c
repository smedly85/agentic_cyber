#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libgen.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>
#include <limits.h>

int main(int argc, char *argv[]) {
    int separator_index = -1;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--") == 0) {
            separator_index = i;
            break;
        }
    }

    int options_end = separator_index == -1 ? argc : separator_index;
    for (int i = 1; i < options_end; i++) {
        if (argv[i][0] == '-' && strcmp(argv[i], "-") != 0) {
            fprintf(stderr, "mkdir: unrecognized option '%s'\nTry 'mkdir --help' for more information.\n", argv[i]);
            return 1;
        }
    }

    int operands_start = separator_index == -1 ? 1 : separator_index + 1;
    if (operands_start >= argc) {
        fprintf(stderr, "mkdir: missing operand\nTry 'mkdir --help' for more information.\n");
        return 1;
    }

    int any_error = 0;
    for (int i = operands_start; i < argc; i++) {
        char *op = argv[i];
        char *d_path = strdup(op);
        char *b_path = strdup(op);
        if (!d_path || !b_path) {
            fprintf(stderr, "mkdir: out of memory\n");
            exit(1);
        }

        char *parent = dirname(d_path);
        char *file = basename(b_path);
        struct stat st;

        if (stat(parent, &st) != 0) {
            int err = errno;
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", op, strerror(err));
            any_error = 1;
        } else if (!S_ISDIR(st.st_mode)) {
            errno = ENOTDIR;
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", op, strerror(errno));
            any_error = 1;
        } else {
            char full[PATH_MAX];
            snprintf(full, sizeof(full), "%s/%s", parent, file);
            if (stat(full, &st) == 0) {
                errno = EEXIST;
                fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", op, strerror(errno));
                any_error = 1;
            } else if (mkdir(full, 0777) != 0) {
                int err = errno;
                fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", op, strerror(err));
                any_error = 1;
            }
        }

        free(d_path);
        free(b_path);
    }

    return any_error ? 1 : 0;
}
