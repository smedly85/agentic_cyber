#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libgen.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "mkdir: missing operand\nTry 'mkdir --help' for more information.\n");
        exit(1);
    }

    int first_operand = 1;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--") == 0) {
            first_operand = i + 1;
            break;
        }
        if (argv[i][0] == '-' && strcmp(argv[i], "-") != 0) {
            fprintf(stderr, "mkdir: unrecognized option '%s'\nTry 'mkdir --help' for more information.\n", argv[i]);
            exit(1);
        }
    }

    if (first_operand >= argc) {
        fprintf(stderr, "new_mkdir: missing operand\n");
        exit(1);
    }

    int any_failure = 0;
    for (int i = first_operand; i < argc; i++) {
        char *path = argv[i];
        char *dup = strdup(path);
        if (!dup) {
            fprintf(stderr, "new_mkdir: memory allocation failed\n");
            exit(2);
        }
        char *parent = dirname(dup);

        struct stat sb;
        if (stat(parent, &sb) != 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
            any_failure = 1;
            free(dup);
            continue;
        }
        if (!S_ISDIR(sb.st_mode)) {
            fprintf(stderr, "mkdir: cannot create directory '%s': Not a directory\n", path);
            any_failure = 1;
            free(dup);
            continue;
        }

        if (stat(path, &sb) == 0) {
            fprintf(stderr, "mkdir: cannot create directory '%s': File exists\n", path);
            any_failure = 1;
            free(dup);
            continue;
        }

        if (mkdir(path, 0777) != 0) {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
            any_failure = 1;
        }

        free(dup);
    }

    exit(any_failure ? 1 : 0);
}
