#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libgen.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    int i;
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--") == 0) {
            break;
        } else if (argv[i][0] == '-' && strcmp(argv[i], "-") != 0) {
            fprintf(stderr, "new_mkdir: invalid option -- '%s'\n", argv[i] + 1);
            exit(1);
        }
    }

    int operands_start = (i < argc) ? i + 1 : 1;
    if (operands_start >= argc) {
        fprintf(stderr, "new_mkdir: missing operand\n");
        exit(1);
    }

    int errors = 0;
    for (int j = operands_start; j < argc; j++) {
        char *path = argv[j];
        char *path_copy = strdup(path);
        if (!path_copy) {
            fprintf(stderr, "new_mkdir: memory error\n");
            exit(1);
        }
        char *dir = dirname(path_copy);
        char *base_copy = strdup(path);
        if (!base_copy) {
            free(path_copy);
            fprintf(stderr, "new_mkdir: memory error\n");
            exit(1);
        }
        char *base = basename(base_copy);

        struct stat st;
        if (stat(dir, &st) != 0) {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': %s\n",
                    path, (errno == ENOENT) ? "No such file or directory" : strerror(errno));
            errors++;
            free(path_copy);
            free(base_copy);
            continue;
        }

        if (!S_ISDIR(st.st_mode)) {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': Not a directory\n", path);
            errors++;
            free(path_copy);
            free(base_copy);
            continue;
        }

        size_t full_len = strlen(dir) + strlen(base) + 2;
        char *full_path = malloc(full_len);
        if (!full_path) {
            free(path_copy);
            free(base_copy);
            fprintf(stderr, "new_mkdir: memory error\n");
            exit(1);
        }
        strcpy(full_path, dir);
        if (dir[strlen(dir)-1] != '/') strcat(full_path, "/");
        strcat(full_path, base);

        if (stat(full_path, &st) == 0) {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': File exists\n", path);
            errors++;
            free(full_path);
            free(path_copy);
            free(base_copy);
            continue;
        }

        if (mkdir(full_path, 0777) == -1) {
            fprintf(stderr, "new_mkdir: cannot create directory '%s': %s\n", path, strerror(errno));
            errors++;
        }
        free(full_path);
        free(path_copy);
        free(base_copy);
    }
    return errors != 0;
}